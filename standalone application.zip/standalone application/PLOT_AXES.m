function varargout = PLOT_AXES(varargin)
% PLOT_AXES MATLAB code for PLOT_AXES.fig
%      PLOT_AXES, by itself, creates a new PLOT_AXES or raises the existing
%      singleton*.
%
%      H = PLOT_AXES returns the handle to a new PLOT_AXES or the handle to
%      the existing singleton*.
%
%      PLOT_AXES('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PLOT_AXES.M with the given input arguments.
%
%      PLOT_AXES('Property','Value',...) creates a new PLOT_AXES or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PLOT_AXES_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PLOT_AXES_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PLOT_AXES

% Last Modified by GUIDE v2.5 02-Jan-2023 23:26:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PLOT_AXES_OpeningFcn, ...
                   'gui_OutputFcn',  @PLOT_AXES_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PLOT_AXES is made visible.
function PLOT_AXES_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PLOT_AXES (see VARARGIN)

% Choose default command line output for PLOT_AXES
% handles.output = hObject;
handles.output = hObject;
Unt=get(0,'Units');
p=get(0,'Screensize');
set(hObject,'Units',Unt);
figsize=get(hObject,'Position');
wf=figsize(3);
hf=figsize(4);ws=p(3);
hs=p(4);
pfig=[(ws-wf)/2 (hs-hf)/2 wf hf];
set(hObject,'position',pfig);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes PLOT_AXES wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PLOT_AXES_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global time sol r s t u v r1 s1 t1 u1 v1 x1 y1 xdata ydata xlab ylab head1 head2
figure()
cla
plot(xdata,ydata,'LineWidth',1.5,'Color',[rand rand rand])
xlabel(xlab)
ylabel(ylab)
title(strcat(' Graph of ',head2,' vs ',head1))
grid minor





% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton6
global x1 y1 s t u v r
x1=get(handles.radiobutton6,'value');
y1=set(handles.radiobutton7,'value',0);
s=set(handles.radiobutton2,'value',0);
t=set(handles.radiobutton3,'value',0);
u=set(handles.radiobutton4,'value',0);
v=set(handles.radiobutton5,'value',0);
r=set(handles.radiobutton1,'value',0);


% --- Executes on button press in radiobutton7.
function radiobutton7_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton7
global y1 x1 r s t u v
y1=get(handles.radiobutton7,'value');
x1=set(handles.radiobutton6,'value',0);
s=set(handles.radiobutton2,'value',0);
t=set(handles.radiobutton3,'value',0);
u=set(handles.radiobutton4,'value',0);
v=set(handles.radiobutton5,'value',0);
r=set(handles.radiobutton1,'value',0);





% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
global r s t u v time sol r1 x1 y1 xdata ydata xlab ylab head1 head2
r=get(handles.radiobutton1,'value');
s=set(handles.radiobutton2,'value',0);
t=set(handles.radiobutton3,'value',0);
u=set(handles.radiobutton4,'value',0);
v=set(handles.radiobutton5,'value',0);
r1=sol(:,1);
if x1==1
    set(handles.edit1,'string','Y1')
    xlab='Y1';
    head1=' Y1 ';
    xdata=r1;
elseif y1==1
    set(handles.edit2,'string','Y1')
    ylab='Y1';
    ydata=r1;
    head2=' Y1 ';
else
    errordlg('Please choose AXIS','ERROR','MODAL') 
end
    




% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2
global r s t u v s1 time sol x1 y1 xdata ydata xlab ylab head1 head2
s=get(handles.radiobutton2,'value');
r=set(handles.radiobutton1,'value',0);
t=set(handles.radiobutton3,'value',0);
u=set(handles.radiobutton4,'value',0);
v=set(handles.radiobutton5,'value',0);
s1=sol(:,2);
if x1==1
    set(handles.edit1,'string','Y2')
    xdata=s1;
    xlab='Y2';
    head1=' Y2 ';
elseif y1==1
    set(handles.edit2,'string','Y2')
    ydata=s1;
    ylab='Y2';
    head2=' Y2 ';
else
    errordlg('Please choose AXIS','ERROR','MODAL') 
end



% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
global t r s t01 u v time sol x1 y1 xdata ydata xlab ylab head1 head2
t=get(handles.radiobutton3,'value');
s=set(handles.radiobutton2,'value',0);
r=set(handles.radiobutton1,'value',0);
u=set(handles.radiobutton4,'value',0);
v=set(handles.radiobutton5,'value',0);
t01=sol(:,3);
if x1==1
    set(handles.edit1,'string','Y''1')
    xdata=t01;
    xlab='Y''1';
    head1=' Y''1 ';
    
elseif y1==1
    set(handles.edit2,'string','Y''1')
    ydata=t01;
    ylab='Y''1';
    head2=' Y''1 ';
    
else
    errordlg('Please choose AXIS','ERROR','MODAL') 
end

% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4
global u r s t v u1 time sol x1 y1 xdata ydata xlab ylab head1 head2
u=get(handles.radiobutton4,'value');
s=set(handles.radiobutton2,'value',0);
t=set(handles.radiobutton3,'value',0);
r=set(handles.radiobutton1,'value',0);
v=set(handles.radiobutton5,'value',0);
u1=sol(:,4);
if x1==1
    set(handles.edit1,'string','Y''2')
    xdata=u1;
    xlab='Y''2';
    head1=' Y''2 ';
    
elseif y1==1
    set(handles.edit2,'string','Y''2')
    ydata=u1;
    ylab=' Y''2 ';
    head2=' Y''2 ';
    
else
    errordlg('Please choose AXIS','ERROR','MODAL') 
end




% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5
global v r t u s v1 time sol x1 y1 xdata ydata xlab ylab head1 head2
v=get(handles.radiobutton5,'value');
s=set(handles.radiobutton2,'value',0);
t=set(handles.radiobutton3,'value',0);
u=set(handles.radiobutton4,'value',0);
r=set(handles.radiobutton1,'value',0);
v1=time(:,1);
if x1==1
    set(handles.edit1,'string','time')
    xdata=v1;
    xlab=' Time ';
    head1=' Time ';
elseif y1==1
    set(handles.edit2,'string','time')
    ydata=v1;
    ylab=' Time ';
    head2=' Time ';
else
    errordlg('Please choose AXIS','ERROR','modal') 
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double



% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double



% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figlist=findobj(allchild(0),'flat','type','figure');
f=length(figlist);
for i=1:f
    close(figure(i))
end
    

% --------------------------------------------------------------------
function file1_Callback(hObject, eventdata, handles)
% hObject    handle to file1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function tool1_Callback(hObject, eventdata, handles)
% hObject    handle to tool1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function overplot1_Callback(hObject, eventdata, handles)
% hObject    handle to overplot1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
figlist=sort(get(0,'children'),'descend');
 if length(figlist)<=2
     errordlg('NO FIGURES TO OVERPLOT','ERROR','modal')
   return;
 end
for i=1:length(figlist)
    j{i}=figlist(i).Number;
end                
j=cell2mat(j);
j=sort(j);
u=length(j);  %here figures are getting open in reverse manner i.e plot 1 is plot3 or vice versa, hence this arrangement is done.
for i=1:length(j)
    fig{i}=figure(j(i));
end
h=findobj(figlist,'type','line');
for i=1:length(j) 
  A(:,i)=findobj(fig{i},'type','line');
end
A=flip(A);
A=A(:);
k=findobj(fig{1},'type','axes'); 
p=k(1).XLim;
a=cell(size(A,2));
% H=get(A,'DisplayName')
for i=1:length(A)
a{i}=['plot',num2str(u-i+1)];
end
[s,v] = listdlg('PromptString','Select the figures','Name','Figures Options',...
                'SelectionMode','multiple','ListSize',[250 300],...
                'ListString',a);
for i=1:length(A)
   zz{i}=[A(i).XData; A(i).YData]';
end
if v==1
q=figure();
cla;
set(gca,'xlim',p);
for i=1:length(s)
 plot(zz{s(i)}(:,1),zz{s(i)}(:,2));
 hold on
end
xlabel(''),ylabel('')
% legend(strcat('grms= ',num2str(grms')))
title(strcat(['COMPARISON OF ','PLOTS ', num2str(u-s+1)]))
legend(a(s))
grid minor  
else
    return;
end

% --------------------------------------------------------------------
function copy1_Callback(hObject, eventdata, handles)
% hObject    handle to copy1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figlist=findobj(allchild(0),'flat','type','figure');   
F=length(figlist); 
                             
if F>2   
     h = waitbar(0,'Please Wait! Your Figures are being copied to MS Word.');
        for i=1:1000
            p=waitbar(i/1000,h);
        end
        close(p)  
word=actxserver('word.application');    
set(word,'visible',1)
doc1=invoke(word.documents,'add');
word.Selection.ParagraphFormat.Alignment=3;
   for i=1:F-2                                               
     print(figure(i),'-dmeta');         
     invoke(word.Selection,'Paste');    
   end
else
    warndlg('No Figures to Save in Word Document','WARNING','modal')
end
   
% --------------------------------------------------------------------
function coordinate1_Callback(hObject, eventdata, handles)
% hObject    handle to coordinate1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
figlist=sort(get(0,'children'),'descend');
 if length(figlist)<=2
     errordlg('NO FIGURES TO CHOOSE.','ERROR','modal')
   return;
 end
 for i=1:length(figlist)
     j{i}=figlist(i).Number;
 end                
 j=cell2mat(j);
 j=sort(j);
% for i=1:length(j)
%     fig{i}=figure(j(i))
% end
for i=1:length(figlist)-2
a{i}=['Figure',num2str(j(i))];
end
 
[s,v] = listdlg('PromptString','Select the figure','Name','Figures Options',...
                'SelectionMode','single','ListSize',[250 300],...
                'ListString',a);
% msgbox('Press Enter from Keyboard after selecting points. The required points are shown in command window','NOTE')
 if v==1
    figure(s)
 else
     return
 end

 [x_coord y_coord]=ginput;
 o=[x_coord y_coord];
[s1,v1] = listdlg('PromptString','X_coord.  Y_coord.','Name','POINTS',...
                'ListSize',[250 300],...
                'ListString',num2str(o));
%  disp(['   x_coord    y_coord'])
%  disp([x_coord,   y_coord])
%  
%  
 % --------------------------------------------------------------------
function open1_Callback(hObject, eventdata, handles)
% hObject    handle to open1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename path]=uigetfile('*.fig','SELECT THE FIGURE FILE TO OPEN');
if filename==0 
    return;
end
    openfig(strcat(path,filename));

% --------------------------------------------------------------------
function save1_Callback(hObject, eventdata, handles)
% hObject    handle to save1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
figlist=findobj(allchild(0),'flat','type','figure');   
% F=length(figlist);   
if length(figlist)>2
[filename path]=uiputfile('.fig');
if filename==0 
    return;
end
L=length(filename);              
k=L-4;
j=filename(1:k);
for i=1:length(figlist)-2
    saveas(figure(i),fullfile(path,[j num2str(i) '.fig']));
end
else
    warndlg('No Figures to Save. First Plot the Figures ','WARNING','modal')
end


% --------------------------------------------------------------------
function print1_Callback(hObject, eventdata, handles)
% hObject    handle to print1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg

% --------------------------------------------------------------------
function exit1_Callback(hObject, eventdata, handles)
% hObject    handle to exit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
X=questdlg('Are you sure you want to Exit!','EXIT');
if strcmp(X,'Yes')
    clc
    close all
else 
end


% --------------------------------------------------------------------
function operation1_Callback(hObject, eventdata, handles)
% hObject    handle to operation1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function extract1_Callback(hObject, eventdata, handles)
% hObject    handle to extract1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global time sol
[filename path]=uiputfile('.xlsx','SAVE FILE AS');
if filename==0 
    return;
end
xlswrite(strcat(path,filename),[time sol],1,'B2');
xlswrite(strcat(path,filename),{'TIME'},1,'B1')
xlswrite(strcat(path,filename),{'Y1'},1,'C1')
xlswrite(strcat(path,filename),{'Y2'},1,'D1')
xlswrite(strcat(path,filename),{'Y''1'},1,'E1')
xlswrite(strcat(path,filename),{'Y''2'},1,'F1')


% --------------------------------------------------------------------
function equation1_Callback(hObject, eventdata, handles)
% hObject    handle to equation1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox('This function is yet to create, sorry for the inconvenience.','WARNING')


% --------------------------------------------------------------------
function event1_Callback(hObject, eventdata, handles)
% hObject    handle to event1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a1 b1 c1 d1 e1 f1 g1 a2 b2 c2 d2 e2 f2 g2 solver11
k=b1/b2;
k1=a2/a1;
solver11=@(t,y) [ y(3);
               y(4);
%         (1/(a1-k*a2)).*((k*c2-c1).*y(3)+(k*d2-d1).*y(4)+(k*e2-e1).*y(1)+(k*f2-f1).*y(2)+k*g2-g1);
%         (1/(1-k1*b1)).*((k1*c1-c2).*y(3)+(k1*d1-d2).*y(4)+(k1*e1-e2).*y(1)+(k1*f1-f2).*y(2)+k1*g1-g2); ];
(1/(a1-k*a2)).*((k*c2(t)-c1(t)).*y(3)+(k*d2(t)-d1(t)).*y(4)+(k*e2(t)-e1(t)).*y(1)+(k*f2(t)-f1(t)).*y(2)+k*g2(t)-g1(t));
        (1/(1-k1*b1)).*((k1*c1(t)-c2(t)).*y(3)+(k1*d1(t)-d2(t)).*y(4)+(k1*e1(t)-e2(t)).*y(1)+(k1*f1(t)-f2(t)).*y(2)+k1*g1(t)-g2(t)); ];
    event_finder             

    
    
    
    
    
    
    