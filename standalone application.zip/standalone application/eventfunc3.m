function [value isterminal direction]=eventfunc3(t,y)
value=y(3); 
isterminal=0;
direction=0;
end