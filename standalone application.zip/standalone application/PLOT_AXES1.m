function varargout = PLOT_AXES1(varargin)
% PLOT_AXES1 MATLAB code for PLOT_AXES1.fig
%      PLOT_AXES1, by itself, creates a new PLOT_AXES1 or raises the existing
%      singleton*.
%
%      H = PLOT_AXES1 returns the handle to a new PLOT_AXES1 or the handle to
%      the existing singleton*.
%
%      PLOT_AXES1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PLOT_AXES1.M with the given input arguments.
%
%      PLOT_AXES1('Property','Value',...) creates a new PLOT_AXES1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PLOT_AXES1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PLOT_AXES1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PLOT_AXES1

% Last Modified by GUIDE v2.5 02-Jan-2023 20:17:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PLOT_AXES1_OpeningFcn, ...
                   'gui_OutputFcn',  @PLOT_AXES1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PLOT_AXES1 is made visible.
function PLOT_AXES1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PLOT_AXES1 (see VARARGIN)

% Choose default command line output for PLOT_AXES1
% handles.output = hObject;
handles.output = hObject;
Unt=get(0,'Units');
p=get(0,'Screensize');
set(hObject,'Units',Unt);
figsize=get(hObject,'Position');
wf=figsize(3);
hf=figsize(4);ws=p(3);
hs=p(4);
pfig=[(ws-wf)/2 (hs-hf)/2 wf hf];
set(hObject,'position',pfig);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes PLOT_AXES1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PLOT_AXES1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global  xdata1 ydata1 xlab1 ylab1 head11 head22
figure()
cla
plot(xdata1,ydata1,'LineWidth',1.5,'Color',[rand rand rand])
xlabel(xlab1)
ylabel(ylab1)
title(strcat(' Graph of ',head22,' vs ',head11))
grid minor





% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figlist=findobj(allchild(0),'flat','type','figure');
f=length(figlist);
for i=1:f
    close(figure(i))
end
    




% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
global x11 y11 r11 s11 t111 time1 sol1 xdata1 xlab1 head11 ylab1 ydata1 head22
r11=get(handles.radiobutton3,'value');
s11=set(handles.radiobutton4,'value',0);
t111=set(handles.radiobutton5,'value',0);
xx=sol1(:,1);
if x11==1
    set(handles.text4,'string','Y')
    xlab1='Y';
    head11=' Y ';
    xdata1=xx;
elseif y11==1
    set(handles.text5,'string','Y')
    ylab1='Y';
    ydata1=xx;
    head22=' Y ';
else
    errordlg('Please choose AXIS.','ERROR','MODAL') 
end




% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4

global x11 y11 r11 s11 t111 time1 sol1 xdata1 xlab1 head11 ylab1 ydata1 head22
s11=get(handles.radiobutton4,'value');
r11=set(handles.radiobutton3,'value',0);
t111=set(handles.radiobutton5,'value',0);
yy=sol1(:,2);
if x11==1
    set(handles.text4,'string','Y''')
    xlab1='Y''';
    head11=' Y'' ';
    xdata1=yy;
elseif y11==1
    set(handles.text5,'string','Y''')
    ylab1='Y''';
    ydata1=yy;
    head22=' Y'' ';
else
    errordlg('Please choose AXIS.','ERROR','MODAL') 
end




% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5

global x11 y11 r11 s11 t111 time1 sol1 xdata1 xlab1 head11 ylab1 ydata1 head22
t111=get(handles.radiobutton5,'value');
r11=set(handles.radiobutton3,'value',0);
s11=set(handles.radiobutton4,'value',0);
zz=time1(:,1);
if x11==1
    set(handles.text4,'string','Time')
    xlab1='Time';
    head11=' Time ';
    xdata1=zz;
elseif y11==1
    set(handles.text5,'string','Time')
    ylab1='Time';
    ydata1=zz;
    head22=' Time ';
else
    errordlg('Please choose AXIS.','ERROR','MODAL') 
end






% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
global x11 y11 r11 s11 t111
x11=get(handles.radiobutton1,'value');
y11=set(handles.radiobutton2,'value',0);
s11=set(handles.radiobutton4,'value',0);
t111=set(handles.radiobutton5,'value',0);
r11=set(handles.radiobutton3,'value',0);




% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2
global x11 y11 r11 s11 t111
y11=get(handles.radiobutton2,'value');
x11=set(handles.radiobutton1,'value',0);
s11=set(handles.radiobutton4,'value',0);
t111=set(handles.radiobutton5,'value',0);
r11=set(handles.radiobutton3,'value',0);


% --------------------------------------------------------------------
function file1_Callback(hObject, eventdata, handles)
% hObject    handle to file1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Tools1_Callback(hObject, eventdata, handles)
% hObject    handle to Tools1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function opearation1_Callback(hObject, eventdata, handles)
% hObject    handle to opearation1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function extract_Callback(hObject, eventdata, handles)
% hObject    handle to extract (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global time1 sol1
[filename path]=uiputfile('.xlsx','SAVE FILE AS');
if filename==0 
    return;
end
xlswrite(strcat(path,filename),[time1 sol1],1,'B2');
xlswrite(strcat(path,filename),{'TIME'},1,'B1');
xlswrite(strcat(path,filename),{'Y'},1,'C1');
xlswrite(strcat(path,filename),{'Y'''},1,'D1');


% --------------------------------------------------------------------
function equation1_Callback(hObject, eventdata, handles)
% hObject    handle to equation1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a11 b11 c11 d11 co1 co2
msgbox('This function is yet to create, sorry for the inconvenience.','WARNING')

% a1=strcat(num2str(a11),'*','D2y');
% b1=strcat(num2str(b11),'*','Dy');
% c1=strcat(num2str(c11),'*','y');
% d1=num2str(d11);
% p=strcat(a1,'+',b1,'+',c1,'+',d1);
% g=num2str(co1);
% h=num2str(co2);
% g1=strcat('y(0)=',g);
% h1=strcat('Dy(0)=',h);
% q=dsolve(p,g1,h1);
% q=simplify(q);
% msgbox(sprintf('%s',q),'Solution');

% --------------------------------------------------------------------
function over1_Callback(hObject, eventdata, handles)
% hObject    handle to over1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
figlist=sort(get(0,'children'),'descend');
 if length(figlist)<=2
     errordlg('NO FIGURES TO OVERPLOT.','ERROR','modal')
   return;
 end
for i=1:length(figlist)
    j{i}=figlist(i).Number;
end                
j=cell2mat(j);
j=sort(j);
for i=1:length(j)
    fig{i}=figure(j(i));
end
h=findobj(figlist,'type','line');
u=length(j);
for i=1:length(j) 
  A(:,i)=findobj(fig{i},'type','line');
end
A=flip(A);
A=A(:);
k=findobj(fig{1},'type','axes'); 
p=k(1).XLim;
a=cell(size(A,2));
% H=get(A,'DisplayName')
for i=1:length(A)
a{i}=['plot',num2str(u-i+1)]
end
[s,v] = listdlg('PromptString','Select the figures','Name','Figures Options',...
                'SelectionMode','multiple','ListSize',[250 300],...
                'ListString',a)
for i=1:length(A)
   zz{i}=[A(i).XData; A(i).YData]';
end
if v==1
q=figure();
cla;
set(gca,'xlim',p);
for i=1:length(s)
 plot(zz{s(i)}(:,1),zz{s(i)}(:,2));
 hold on
end
% xlabel(''),ylabel('')
% legend(strcat('grms= ',))
title(strcat(['COMPARISON OF ','PLOTS ', num2str(u-s+1)]))
legend(a(s))
grid minor  
else
    return;
end

% --------------------------------------------------------------------
function copy1_Callback(hObject, eventdata, handles)
% hObject    handle to copy1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figlist=findobj(allchild(0),'flat','type','figure');   
F=length(figlist); 
                             
if F>2   
     h = waitbar(0,'Please Wait! Your Figures are being copied to MS Word.');
        for i=1:1000
            p=waitbar(i/1000,h);
        end
        close(p)  
word=actxserver('word.application');    
set(word,'visible',1)
doc1=invoke(word.documents,'add');
word.Selection.ParagraphFormat.Alignment=3;
   for i=1:F-2                                               
     print(figure(i),'-dmeta');         
     invoke(word.Selection,'Paste');    
   end
else
    warndlg('No Figures to Save in Word Document.','WARNING','modal')
end
    
% --------------------------------------------------------------------
function coordinates1_Callback(hObject, eventdata, handles)
% hObject    handle to coordinates1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figlist=sort(get(0,'children'),'descend');
 if length(figlist)<=2
     errordlg('NO FIGURES TO CHOOSE.','ERROR','modal')
   return;
 end
 for i=1:length(figlist)
     j{i}=figlist(i).Number;
 end                
 j=cell2mat(j);
 j=sort(j);
% for i=1:length(j)
%     fig{i}=figure(j(i))
% end
for i=1:length(figlist)-2
a{i}=['Figure',num2str(j(i))];
end
 
[s,v] = listdlg('PromptString','Select the figure','Name','Figures Options',...
                'SelectionMode','single','ListSize',[250 300],...
                'ListString',a);
% msgbox('Press Enter from Keyboard after selecting points. The required points are shown in command window','NOTE')
 if v==1
    figure(s)
 else
     return
 end

 [x_coord y_coord]=ginput;
%  msgbox(sprintf('%s %s',x_coord, y_coord),'Solution');
o=[x_coord y_coord];
[s1,v1] = listdlg('PromptString','X_coord.  Y_coord.','Name','POINTS',...
                'ListSize',[250 300],...
                'ListString',num2str(o));

%  disp(['   x_coord    y_coord'])
%  disp([x_coord,   y_coord])

% --------------------------------------------------------------------
function open1_Callback(hObject, eventdata, handles)
% hObject    handle to open1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[filename path]=uigetfile('*.fig','SELECT THE FIGURE FILE TO OPEN');
if filename==0 
    return;
end
    openfig(strcat(path,filename));

% --------------------------------------------------------------------
function save1_Callback(hObject, eventdata, handles)
% hObject    handle to save1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

figlist=findobj(allchild(0),'flat','type','figure');   
% F=length(figlist);   
if length(figlist)>2
[filename path]=uiputfile('.fig');
if filename==0 
    return;
end
L=length(filename);              
k=L-4;
j=filename(1:k);
for i=1:length(figlist)-2
    saveas(figure(i),fullfile(path,[j num2str(i) '.fig']));
end
else
    warndlg('No Figures to Save. First Plot the Figures. ','WARNING','modal')
end


% --------------------------------------------------------------------
function print1_Callback(hObject, eventdata, handles)
% hObject    handle to print1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg

% --------------------------------------------------------------------
function exit1_Callback(hObject, eventdata, handles)
% hObject    handle to exit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
X=questdlg('Are you sure you want to Exit!','EXIT');
if strcmp(X,'Yes')
    clc
    close all
else 
end


% --------------------------------------------------------------------


% --------------------------------------------------------------------
function event1_Callback(hObject, eventdata, handles)
% hObject    handle to event1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global event11 event22 a11 b11 c11 d11 co1 co2 tspan
init=[co1 co2];
% solver=@(t,y) [y(2);
%               (-1/(a11(t)))*(b11(t)*y(2)+c11(t)*y(1)+d11(t));];
%  [time1 sol1]=ode45(solver,tspan,init); 
solver=@(t,y) [y(2)
              (-1/(eval(a11)))*(eval(b11)*y(2)+eval(c11)*y(1)+eval(d11));];
W = questdlg('Select the Condition you want to Evaluate.','Options','Time at Y=0','Time at Y''=0','Cancel');
switch W
    case 'Time at Y=0'
       opt=odeset('Events',@eventfunc1);
        [time1 sol1 te1 ye ie]=ode45(solver,tspan,init,opt);
        o=[te1 ye(:,1)];
        [s1,v1] = listdlg('PromptString',' X_coord.      Y_coord. ','Name','POINTS',...
                'ListSize',[250 300],...
                'ListString',num2str(o));
        
    case 'Time at Y''=0'
        opt=odeset('Events',@eventfunc2);
        [time1 sol1 te2 ye ie]=ode45(solver,tspan,init,opt);
        o=[te2 ye(:,2)];
        [s1,v1] = listdlg('PromptString',' X_coord.      Y_coord. ','Name','POINTS',...
                'ListSize',[250 300],...
                'ListString',num2str(o));
     case 'cancel' %it is required since 'switch case' algorithm does not read last case hence it as a dummy case. this case is not present in gui.
end
