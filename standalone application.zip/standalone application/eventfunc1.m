function [value isterminal direction]=eventfunc1(t,y)
value=y(1);
isterminal=0;
direction=0;
end