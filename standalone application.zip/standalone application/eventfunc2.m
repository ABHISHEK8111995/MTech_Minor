function [value isterminal direction]=eventfunc2(t,y)
value=y(2); 
isterminal=0;
direction=0;
end