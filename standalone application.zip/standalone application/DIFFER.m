function varargout = DIFFER(varargin)
% DIFFER MATLAB code for DIFFER.fig
%      DIFFER, by itself, creates a new DIFFER or raises the existing
%      singleton*.
%
%      H = DIFFER returns the handle to a new DIFFER or the handle to
%      the existing singleton*.
%
%      DIFFER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DIFFER.M with the given input arguments.
%
%      DIFFER('Property','Value',...) creates a new DIFFER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DIFFER_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DIFFER_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DIFFER

% Last Modified by GUIDE v2.5 01-Jan-2023 16:08:32

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DIFFER_OpeningFcn, ...
                   'gui_OutputFcn',  @DIFFER_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DIFFER is made visible.
function DIFFER_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DIFFER (see VARARGIN)

% Choose default command line output for DIFFER
% handles.output = hObject;
handles.output = hObject;
Unt=get(0,'Units');
p=get(0,'Screensize');
set(hObject,'Units',Unt);
figsize=get(hObject,'Position');
wf=figsize(3);
hf=figsize(4);ws=p(3);
hs=p(4);
pfig=[(ws-wf)/2 (hs-hf)/2 wf hf];
set(hObject,'position',pfig);
% Update handles structure
guidata(hObject, handles);


% UIWAIT makes DIFFER wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DIFFER_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure

global K I
% mlock 
persistent x
x=K;
if (isempty(x))
     mess1
end






function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
global a1
% a1=str2num(get(handles.edit1,'string'));
% % a1=inline(a1);
% if isempty(a1)
%     warndlg('Y1'''', Y2'''' MUST BE NUMERIC. ','WARNING','modal')
% else 
%     return
% end


a1=(get(handles.edit1,'string'));
A=strfind(a1,'y');
B=strfind(a1,'Y');        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    a1=strrep(a1,'y','y(1)');
    a1=strrep(a1,'Y','y(2)');
else
end


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
global b1
% b1=str2num(get(handles.edit2,'string'));
% % b1=inline(b1);
% if isempty(b1)
%     warndlg('Y1'''', Y2'''' MUST BE NUMERIC. ','WARNING','modal')
% else 
%     return
% end



b1=(get(handles.edit2,'string'));
A=strfind(b1,'y');
B=strfind(b1,'Y');        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    b1=strrep(b1,'y','y(1)');
    b1=strrep(b1,'Y','y(2)');
else
end


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
global c1
c1=(get(handles.edit3,'string'));
% c1=inline(c1);

A=strfind(c1,'y');
B=strfind(c1,'Y');     %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    c1=strrep(c1,'y','y(1)');
    c1=strrep(c1,'Y','y(2)');
else
end







% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
global d1
d1=(get(handles.edit4,'string'));
A=strfind(d1,'y');
B=strfind(d1,'Y') ;        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    d1=strrep(d1,'y','y(1)');
    d1=strrep(d1,'Y','y(2)');
else
end


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double
global e1
e1=(get(handles.edit5,'string'));
A=strfind(e1,'y');
B=strfind(e1,'Y') ;        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    e1=strrep(e1,'y','y(1)');
    e1=strrep(e1,'Y','y(2)');
else
end


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
global f1
f1=(get(handles.edit6,'string'));
A=strfind(f1,'y');
B=strfind(f1,'Y') ;        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    f1=strrep(f1,'y','y(1)');
    f1=strrep(f1,'Y','y(2)');
else
end



% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double

global g1
g1=(get(handles.edit7,'string'));
A=strfind(g1,'y');
B=strfind(g1,'Y');        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    g1=strrep(g1,'y','y(1)');
    g1=strrep(g1,'Y','y(2)');
else
end



% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double
global a2
% a2=str2num(get(handles.edit8,'string'));
% % a2=inline(a2);
% if isempty(a2)
%     warndlg('Y1'''', Y2'''' MUST BE NUMERIC. ','WARNING','modal')
% else 
%     return
% end


a2=(get(handles.edit8,'string'));
A=strfind(a2,'y');
B=strfind(a2,'Y');        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    a2=strrep(a2,'y','y(1)');
    a2=strrep(a2,'Y','y(2)');
else
end




% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double
global b2
% b2=str2num(get(handles.edit9,'string'));
% if isempty(b2)
%     warndlg('Y1'''', Y2'''' MUST BE NUMERIC. ','WARNING','modal')
% else 
%     return
% end

b2=(get(handles.edit9,'string'));
A=strfind(b2,'y');
B=strfind(b2,'Y');        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    b2=strrep(b2,'y','y(1)');
    b2=strrep(b2,'Y','y(2)');
else
end








% b2=inline(b2);

% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double
global c2
c2=(get(handles.edit10,'string'));
A=strfind(c2,'y');
B=strfind(c2,'Y') ;        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    c2=strrep(c2,'y','y(1)');
    c2=strrep(c2,'Y','y(2)');
else
end



% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double

global d2
d2=(get(handles.edit11,'string'));
A=strfind(d2,'y');
B=strfind(d2,'Y') ;        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    d2=strrep(d2,'y','y(1)');
    d2=strrep(d2,'Y','y(2)');
else
end

% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double

global e2
e2=(get(handles.edit12,'string'));
A=strfind(e2,'y');
B=strfind(e2,'Y') ;        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    e2=strrep(e2,'y','y(1)');
    e2=strrep(e2,'Y','y(2)');
else
end


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double

global f2
f2=(get(handles.edit13,'string'));
A=strfind(f2,'y');
B=strfind(f2,'Y') ;        %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    f2=strrep(f2,'y','y(1)');
    f2=strrep(f2,'Y','y(2)');
else
end


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double

global g2
g2=(get(handles.edit14,'string'));
A=strfind(g2,'y');
B=strfind(g2,'Y') ;       %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    g2=strrep(g2,'y','y(1)');
    g2=strrep(g2,'Y','y(2)');
else
end



% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a1 b1 c1 d1 e1 f1 g1 a2 b2 c2 d2 e2 f2 g2 t0 t1 i1 i2 i3 i4 time sol tspan2 init2
  tspan2=[t0 t1];
  init2=[i1 i2 i3 i4];
%     k=(b1./b2)
%     k1=a2./a1
% p1=a1-k*a2;
% p2=1-k1*b1;
% if ((p2||p1)~=0)             %this is not working. see the logical operator
    solver=@(t,y) [ y(3);
                    y(4);
        (1./(eval(a1)-(eval(b1)./eval(b2)).*eval(a2))).*(((eval(b1)./eval(b2))*eval(c2)-eval(c1)).*y(3)+((eval(b1)./eval(b2))*eval(d2)-eval(d1)).*y(4)+((eval(b1)./eval(b2))*eval(e2)-eval(e1)).*y(1)+((eval(b1)./eval(b2))*eval(f2)-eval(f1)).*y(2)+(eval(b1)./eval(b2))*eval(g2)-eval(g1));
        (1./(1-(eval(a2)./eval(a1))  .*eval(b1))).*(((eval(a2)./eval(a1))*eval(c1)-eval(c2)).*y(3)+((eval(a2)./eval(a1))*eval(d1)-eval(d2)).*y(4)+((eval(a2)./eval(a1))*eval(e1)-eval(e2)).*y(1)+((eval(a2)./eval(a1))*eval(f1)-eval(f2)).*y(2)+(eval(a2)./eval(a1))*eval(g1)-eval(g2)); ];
                   
   [time sol]=ode15s(solver,tspan2,init2);    %for stiff equation and to have less no. of time step we use ode15s

if prod(isfinite(sol(3:6,1)))==1   %any random data to confirm existence of data instead of nan
    PLOT_AXES
    return;
    else 
    errordlg('THE INPUT DATA FOR COUPLED DIFFERENTIAL EQUATION IS WRONG, PLEASE TRY AGAIN WITH DIFFERENT SETS OF DATA AND INITIAL INDEPENDENT VARIABLE VALUE.','ERROR','modal')
end

   


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double

global t0
t0=str2num(get(handles.edit15,'string'));
if isempty(t0)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY','ERROR','modal')
else 
    return
end




% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double
global t1
t1=str2num(get(handles.edit16,'string'));
if isempty(t1)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY','ERROR','modal')
else 
    return
end


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double
global i1
i1=str2num(get(handles.edit20,'string'));
if isempty(i1)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY.','ERROR','modal')
else 
    return
end





% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double
global i3
i3=str2num(get(handles.edit21,'string'));
if isempty(i3)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY.','ERROR','modal')
else 
    return
end


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double
global i2
i2=str2num(get(handles.edit22,'string'));
if isempty(i2)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY.','ERROR','modal')
else 
    return
end

% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit23_Callback(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit23 as text
%        str2double(get(hObject,'String')) returns contents of edit23 as a double

global i4
i4=str2num(get(handles.edit23,'string'));
if isempty(i4)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY.','ERROR','modal')
else 
    return
end



% --- Executes during object creation, after setting all properties.
function edit23_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double
global t00 
t00=str2num(get(handles.edit28,'string'));
if isempty(t00)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY.','ERROR','modal')
else 
    return
end


% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit29_Callback(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit29 as text
%        str2double(get(hObject,'String')) returns contents of edit29 as a double
global t11 
t11=str2num(get(handles.edit29,'string'));
if isempty(t11)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY.','ERROR','modal')
else 
    return
end


% --- Executes during object creation, after setting all properties.
function edit29_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit30_Callback(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit30 as text
%        str2double(get(hObject,'String')) returns contents of edit30 as a double
global co1 
co1=str2num(get(handles.edit30,'string'));
if isempty(co1)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY.','ERROR','modal')
else 
    return
end


% --- Executes during object creation, after setting all properties.
function edit30_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit30 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit31_Callback(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit31 as text
%        str2double(get(hObject,'String')) returns contents of edit31 as a double
global co2 
co2=str2num(get(handles.edit31,'string'));
if isempty(co2)
    errordlg('PLEASE ENTER NUMERIC CONSTANTS ONLY.','ERROR','modal')
else 
    return
end


% --- Executes during object creation, after setting all properties.
function edit31_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit24_Callback(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit24 as text
%        str2double(get(hObject,'String')) returns contents of edit24 as a double
global a11 
% a11=str2double(get(handles.edit24,'string'));
a11=(get(handles.edit24,'string'));
% a11=inline(a11);
A=strfind(a11,'y');
B=strfind(a11,'Y');         %Y for y' or first derivative  
if ~isempty(A)||~isempty(B)
    a11=strrep(a11,'y','y(1)');
    a11=strrep(a11,'Y','y(2)');
else
end


% --- Executes during object creation, after setting all properties.
function edit24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit25_Callback(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit25 as text
%        str2double(get(hObject,'String')) returns contents of edit25 as a double
global b11 
% b11=str2double(get(handles.edit25,'string'));
b11=(get(handles.edit25,'string'));
% b11=inline(b11);
A=strfind(b11,'y');
B=strfind(b11,'Y');
if ~isempty(A)||~isempty(B)
    b11=strrep(b11,'y','y(1)');
     b11=strrep(b11,'Y','y(2)');
else
end




% --- Executes during object creation, after setting all properties.
function edit25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit26 as text
%        str2double(get(hObject,'String')) returns contents of edit26 as a double
global c11 
% c11=str2double(get(handles.edit26,'string'));
c11=(get(handles.edit26,'string'));
% c11=inline(c11);
A=strfind(c11,'y');
B=strfind(c11,'Y');
if ~isempty(A)||~isempty(B)
    c11=strrep(c11,'y','y(1)');
     c11=strrep(c11,'Y','y(2)');
else
end



% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double
global d11 
% d11=str2double(get(handles.edit27,'string'));
d11=(get(handles.edit27,'string'));
% d11=inline(d11);
A=strfind(d11,'y');
B=strfind(d11,'Y');
if ~isempty(A)||~isempty(B)
    d11=strrep(d11,'y','y(1)');
     d11=strrep(d11,'Y','y(2)');
else
end


% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a11 b11 c11 d11 t00 t11 co1 co2 time1 sol1 tspan
if isempty(a11)||isempty(b11)||isempty(c11)||isempty(d11)||isempty(t00)||isempty(t11)||isempty(co1)||isempty(co2)
    errordlg('PLEASE ENTER PARAMETERS IN ALL THE EDIT BOXES.','ERROR','MODAL')
    return
end
tspan=[t00 t11];
init=[co1 co2];                %y(2)=y' and y(1)=y
solver=@(t,y) [y(2);
              (-1/(eval(a11)))*(eval(b11)*y(2)+eval(c11)*y(1)+eval(d11));];  %here since a11(t) is function of t therefore only function interms of t can be written in gui.
 [time1 sol1]=ode15s(solver,tspan,init);      %for function interms of y change a11(t) to a11(y(1)). make changes in others also.
                                              %for stiff equation and to have less no. of time step we use ode15s
 if prod(isfinite(sol1(3:6,1)))==1   %any random data to confirm existence of data instead of nan
    PLOT_AXES1
    return;
    else 
    errordlg('The given sets of data is Incompatible. Either change the Coefficient of Y'''' or Change initial Independent variable value from 0 to something else. eg: 0.001 ','ERROR','modal')
end
    

% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a11 b11 c11 d11 t00 t11 co1 co2
a11=set(handles.edit24,'value',0);
b11=set(handles.edit25,'value',0);
c11=set(handles.edit26,'value',0);
d11=set(handles.edit27,'value',0);
t00=set(handles.edit28,'value',0);
t11=set(handles.edit29,'value',0);
co1=set(handles.edit30,'value',0);
co2=set(handles.edit31,'value',0);
set(handles.edit24,'string','');
set(handles.edit25,'string','');
set(handles.edit26,'string','');
set(handles.edit27,'string','');
set(handles.edit28,'string','');
set(handles.edit29,'string','');
set(handles.edit30,'string','');
set(handles.edit31,'string','');
% clear all


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global a1 b1 c1 d1 e1 f1 g1 a2 b2 c2 d2 e2 f2 g2 t0 t1 i1 i2 i3 i4 
a1=set(handles.edit1,'value',0);
b1=set(handles.edit2,'value',0);
c1=set(handles.edit3,'value',0);
d1=set(handles.edit4,'value',0);
e1=set(handles.edit5,'value',0);
f1=set(handles.edit6,'value',0);
g1=set(handles.edit7,'value',0);
a2=set(handles.edit8,'value',0);
b2=set(handles.edit9,'value',0);
c2=set(handles.edit10,'value',0);
d2=set(handles.edit11,'value',0);
e2=set(handles.edit12,'value',0);
f2=set(handles.edit13,'value',0);
g2=set(handles.edit14,'value',0);
t0=set(handles.edit15,'value',0);
t1=set(handles.edit16,'value',0);
i1=set(handles.edit20,'value',0);
i2=set(handles.edit22,'value',0);
i3=set(handles.edit21,'value',0);
i4=set(handles.edit23,'value',0);
set(handles.edit1,'string','');
set(handles.edit2,'string','');
set(handles.edit3,'string','');
set(handles.edit4,'string','');
set(handles.edit5,'string','');
set(handles.edit6,'string','');
set(handles.edit7,'string','');
set(handles.edit8,'string','');
set(handles.edit9,'string','');
set(handles.edit10,'string','');
set(handles.edit11,'string','');
set(handles.edit12,'string','');
set(handles.edit13,'string','');
set(handles.edit14,'string','');
set(handles.edit15,'string','');
set(handles.edit16,'string','');
set(handles.edit20,'string','');
set(handles.edit21,'string','');
set(handles.edit22,'string','');
set(handles.edit23,'string','');
