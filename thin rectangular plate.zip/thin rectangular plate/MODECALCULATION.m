a = 1;
b = 1;
%%%Mode shape
m = 1;
n = 1;
p=1;
q=1;
%%%Magnitude
A = 1;
%%%x and y modes
x = linspace(0,a,100);
y = linspace(0,b,100);
[xx,yy] = meshgrid(x,y);
phix = sin(m*pi*xx/a);
phiy = sin(n*pi*yy/b);

phix1 = 2*sin(p*pi*xx/a+pi/2); %to get superimposition of two different modes
phiy1 = 2*sin(q*pi*yy/b+pi/2);

%%%displacement / deflection
w = 1; %%some frequency whatever I want

% zzconst = A*phix.*phiy;
% mesh(xx,yy,zzconst)

figure()
cla;
   zz = 5*A*phix.*phiy;
   mesh(xx,yy,zz)

for t = 1:0.01:100
    cla;
    zz = A*phix.*phiy*sin(w*t);
    mesh(xx,yy,zz)
    axis([0 a 0 b -A A])
    view(45,45)
%      drawnow
end
