function [xx yy zzconst]=modes_fixed(i,j)
a1 = 0.3
b1 = 0.3;
A = 1;
%%%x and y modes
x = linspace(0,a1,100);
y = linspace(0,b1,100);
[xx,yy] = meshgrid(x,y);
r = 5*sin(i*pi*xx/a1);
s = 5*sin(j*pi*yy/b1);
zz = r.*s;
zzconst = A*r.*s;
end
